#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1005;
int N = 0, M = 0;
vector<int> G[MAXN];
int part[MAXN], costArr[MAXN];
bool lockedNode[MAXN];
void compute_costs() {
    for (int u = 1; u <= N; ++u) {
        int same = 0, other = 0;
        for (int v : G[u]) {
            if (part[u] == part[v]) ++same;
            else ++other;
        }
        costArr[u] = other - same;
    }
}
pair<int, pair<int,int>> find_best_pair() {
    int best1 = -1, best2 = -1;
    int idx1 = 0, idx2 = 0;
    for (int i = 1; i <= N; ++i) {
        if (lockedNode[i]) continue;
        if (part[i] == 1) {
            if (best1 < costArr[i]) { best1 = costArr[i]; idx1 = i; }
        } else {
            if (best2 < costArr[i]) { best2 = costArr[i]; idx2 = i; }
        }
    }
    if (idx1 == 0 || idx2 == 0) return make_pair(INT_MIN, make_pair(0,0));
    bool connected = false;
    for (int v : G[idx1]) if (v == idx2) { connected = true; break; }
    int gain = costArr[idx1] + costArr[idx2] - (connected ? 1 : 0);
    return make_pair(gain, make_pair(idx1, idx2));
}
void print_partition(const int P[]) {
    cout << "A: [ ";
    for (int i = 1; i <= N; ++i) if (P[i] == 1) cout << i << " ";
    cout << "]\nB: [ ";
    for (int i = 1; i <= N; ++i) if (P[i] == 2) cout << i << " ";
    cout << "]\n\n";
}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    N = 8;
    vector<pair<int,int>> edges = {
        {1,2},{1,5},{1,6},{3,5},{2,6},{3,4},{3,6},{3,7},{3,8},
        {4,7},{4,8},{5,6},{7,8}
    };
    for (auto &e : edges) {
        int u = e.first, v = e.second;
        G[u].push_back(v);
        G[v].push_back(u);
    }
    M = (int)edges.size();
    for (int i = 1; i <= N; ++i) {
        part[i] = (i <= N/2 ? 1 : 2);
        lockedNode[i] = false;
    }
    cout << "Initial Partition:\n";
    print_partition(part);
    int globalMaxGain = INT_MIN;
    int bestP1 = 0, bestP2 = 0;
    vector<int> bestAnswer(N+1);
    int step = 1;
    while (true) {
        compute_costs();
        for (int i = 1; i <= N; ++i) lockedNode[i] = false;
        bool anySwap = false;
        while (true) {
            auto res = find_best_pair();
            int gain = res.first;
            int a = res.second.first;
            int b = res.second.second;
            if (a == 0 || b == 0 || gain == INT_MIN) break;
            cout << "Process " << step++ << ":\n";
            cout << gain << " => " << a << ", " << b << "\n";
            swap(part[a], part[b]);
            lockedNode[a] = lockedNode[b] = true;
            anySwap = true;
            compute_costs();
            if (gain > globalMaxGain) {
                globalMaxGain = gain;
                bestP1 = a; bestP2 = b;
                for (int i = 1; i <= N; ++i) bestAnswer[i] = part[i];
            }
            cout << "Partition after swap:\n";
            print_partition(part);
        }
        if (!anySwap) break;
        break;
    }
    if (globalMaxGain == INT_MIN) {
        cout << "No improving swaps were found.\n";
        cout << "Final partition:\n";
        print_partition(part);
    } else {
        cout << "The Solution of Partition: (MaxGain = " << globalMaxGain
             << ", For Pair <" << bestP1 << "," << bestP2 << ">)\n";
        cout << "Best recorded partition:\n";
        print_partition(bestAnswer.data()-0);
    }
    return 0;
}


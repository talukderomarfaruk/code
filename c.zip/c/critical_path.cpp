#include <bits/stdc++.h>
using namespace std;

#define ll long long
const int SIZE = 1005;

vector<ll> adjList[SIZE];
ll edgeCost[SIZE][SIZE];
ll earliest[SIZE], latest[SIZE];

void CalcEarliestTime(ll node, ll currCost);
ll CalcLatestTime(ll node);
void TraceCriticalRoute(ll node);

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    ll edgeCount = 7;
    char start = 'A';

    vector<tuple<char, char, ll>> edges = {
        make_tuple('A', 'B', 3),
        make_tuple('A', 'C', 2),
        make_tuple('B', 'D', 2),
        make_tuple('C', 'D', 1),
        make_tuple('C', 'E', 3),
        make_tuple('D', 'F', 2),
        make_tuple('E', 'F', 2)
    };

    for (size_t i = 0; i < edges.size(); i++) {
        char u, v;
        ll wt;
        tie(u, v, wt) = edges[i];
        adjList[u - 'A'].push_back(v - 'A');
        edgeCost[u - 'A'][v - 'A'] = wt;
    }

    for (int i = 0; i < SIZE; i++) {
        latest[i] = LLONG_MAX;
    }

    earliest[start - 'A'] = 0;

    cout << "Earliest Start Times:\n";
    CalcEarliestTime(start - 'A', 0);

    cout << "\nLatest Finish Times:\n";
    CalcLatestTime(start - 'A');

    cout << "\nCritical Path: ";
    TraceCriticalRoute(start - 'A');
    cout << "\n";

    return 0;
}

void CalcEarliestTime(ll node, ll currCost) {
    earliest[node] = max(earliest[node], currCost);
    cout << char(node + 'A') << " => ES = " << earliest[node] << "\n";

    for (auto next : adjList[node]) {
        ll wt = edgeCost[node][next];
        CalcEarliestTime(next, earliest[node] + wt);
    }
}

ll CalcLatestTime(ll node) {
    if (adjList[node].empty()) {
        latest[node] = earliest[node];
    }
    for (auto next : adjList[node]) {
        ll wt = edgeCost[node][next];
        ll val = CalcLatestTime(next);
        latest[node] = min(latest[node], val - wt);
    }
    cout << char(node + 'A') << " => TF = " << latest[node] << "\n";
    return latest[node];
}

void TraceCriticalRoute(ll node) {
    if (earliest[node] != latest[node]) return;
    cout << char(node + 'A') << " ";
    for (auto next : adjList[node]) {
        TraceCriticalRoute(next);
    }
}

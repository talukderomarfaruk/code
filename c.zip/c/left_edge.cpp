#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define pb push_back

struct Wire {
    ll index;
    ll leftBound;
    ll rightBound;
    string label;
};

bool hasOverlap(const Wire &a, const Wire &b) {
    return !(a.rightBound < b.leftBound || b.rightBound < a.leftBound);
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int colCount = 8;
    vector<string> upper = {"A", "B", "#", "C", "#", "E", "#", "F"};
    vector<string> lower = {"#", "B", "C", "#", "D", "#", "E", "F"};

    set<string> allNodes;
    for (auto &s : upper) if (s != "#") allNodes.insert(s);
    for (auto &s : lower) if (s != "#") allNodes.insert(s);

    unordered_map<string, int> nodeIndex;
    int nodeId = 0;
    for (auto &nm : allNodes) nodeIndex[nm] = nodeId++;

    int totalNodes = nodeId;
    vector<Wire> wires(totalNodes);
    for (int i = 0; i < totalNodes; i++) {
        wires[i].index = i;
        wires[i].leftBound = LLONG_MAX;
        wires[i].rightBound = LLONG_MIN;
    }

    vector<vector<int>> graph(totalNodes);
    vector<int> indegree(totalNodes, 0);

    for (int c = 0; c < colCount; c++) {
        string top = upper[c], bottom = lower[c];

        if (top != "#") {
            int id = nodeIndex[top];
            wires[id].label = top;
            wires[id].leftBound = min(wires[id].leftBound, (ll)c);
            wires[id].rightBound = max(wires[id].rightBound, (ll)c);
        }
        if (bottom != "#") {
            int id = nodeIndex[bottom];
            wires[id].label = bottom;
            wires[id].leftBound = min(wires[id].leftBound, (ll)c);
            wires[id].rightBound = max(wires[id].rightBound, (ll)c);
        }
        if (top != "#" && bottom != "#" && top != bottom) {
            int u = nodeIndex[top], v = nodeIndex[bottom];
            graph[u].pb(v);
            indegree[v]++;
        }
    }

    set<int> placedWires;
    vector<vector<Wire>> channelTracks;

    while ((int)placedWires.size() < totalNodes) {
        vector<int> readyNodes;
        for (int i = 0; i < totalNodes; i++) {
            if (indegree[i] == 0 && !placedWires.count(i)) {
                readyNodes.pb(i);
            }
        }

        sort(readyNodes.begin(), readyNodes.end(), [&](int a, int b) {
            return wires[a].leftBound < wires[b].leftBound;
        });

        if (readyNodes.empty()) {
            cout << "Cycle detected! Need doglegs.\n";
            return 0;
        }

        vector<Wire> newTrack;
        for (int n : readyNodes) {
            bool canPlace = false;
            if (newTrack.empty()) {
                newTrack.pb(wires[n]);
                canPlace = true;
            } else if (!hasOverlap(newTrack.back(), wires[n])) {
                newTrack.pb(wires[n]);
                canPlace = true;
            }
            if (canPlace) {
                placedWires.insert(n);
                for (int nxt : graph[n]) indegree[nxt]--;
            }
        }
        channelTracks.pb(newTrack);
    }

    cout << "Tracks used: " << channelTracks.size() << endl;
    for (int i = 0; i < (int)channelTracks.size(); i++) {
        cout << "Track " << i + 1 << ": ";
        for (auto &wire : channelTracks[i]) {
            cout << wire.label << " ";
        }
        cout << endl;
    }

    return 0;
}

#include <bits/stdc++.h>
using namespace std;

struct Term {
    vector<int> bits;
    vector<int> minterms;
    bool combined;
};

// Count number of 1's in bits
int countOnes(const vector<int>& bits) {
    return accumulate(bits.begin(), bits.end(), 0);
}

// Check if two terms differ by exactly 1 bit
int differByOneBit(const vector<int>& a, const vector<int>& b) {
    int diff = 0;
    int pos = -1;
    for (int i = 0; i < a.size(); i++) {
        if (a[i] != b[i]) {
            diff++;
            pos = i;
        }
    }
    return diff == 1 ? pos : -1;
}

// Convert integer to binary vector
vector<int> intToBinary(int n, int varCount) {
    vector<int> bits(varCount);
    for (int i = varCount - 1; i >= 0; i--) {
        bits[i] = n % 2;
        n /= 2;
    }
    return bits;
}

// Print term in Boolean expression form
void printTerm(const vector<int>& bits, const vector<char>& varNames) {
    for (int i = 0; i < bits.size(); i++) {
        if (bits[i] == 1) cout << varNames[i];
        else if (bits[i] == 0) cout << varNames[i] << "'";
    }
}

int main() {
    int varCount, mintermCount;
    cout << "Enter number of variables: ";
    cin >> varCount;
    cout << "Enter number of minterms: ";
    cin >> mintermCount;

    vector<int> minterms(mintermCount);
    cout << "Enter minterms (space separated): ";
    for (int i = 0; i < mintermCount; i++) cin >> minterms[i];

    // Variable names
    vector<char> varNames(varCount);
    for (int i = 0; i < varCount; i++) varNames[i] = 'A' + i;

    // Initial terms
    vector<Term> terms;
    for (int i = 0; i < mintermCount; i++) {
        terms.push_back({intToBinary(minterms[i], varCount), {minterms[i]}, false});
    }

    vector<Term> primeImplicants;

    bool canCombine = true;
    while (canCombine) {
        canCombine = false;
        vector<Term> newTerms;
        vector<bool> used(terms.size(), false);

        for (int i = 0; i < terms.size(); i++) {
            for (int j = i + 1; j < terms.size(); j++) {
                int pos = differByOneBit(terms[i].bits, terms[j].bits);
                if (pos != -1) {
                    canCombine = true;
                    vector<int> combinedBits = terms[i].bits;
                    combinedBits[pos] = -1; // '-' represents don't care
                    vector<int> combinedMinterms = terms[i].minterms;
                    combinedMinterms.insert(combinedMinterms.end(), terms[j].minterms.begin(), terms[j].minterms.end());
                    newTerms.push_back({combinedBits, combinedMinterms, false});
                    terms[i].combined = terms[j].combined = true;
                }
            }
        }

        // Add uncombined terms to prime implicants
        for (auto &t : terms) if (!t.combined) primeImplicants.push_back(t);

        // Remove duplicates in newTerms
        sort(newTerms.begin(), newTerms.end(), [](Term &a, Term &b){
            return a.minterms < b.minterms;
        });
        newTerms.erase(unique(newTerms.begin(), newTerms.end(), [](Term &a, Term &b){
            return a.bits == b.bits;
        }), newTerms.end());

        terms = newTerms;
    }

    // Print prime implicants
    cout << "\nPrime Implicants: \n";
    for (auto &t : primeImplicants) {
        for (auto &b : t.bits) {
            if (b == -1) cout << "-";
            else cout << b;
        }
        cout << "  (";
        for (int i = 0; i < t.minterms.size(); i++) {
            cout << t.minterms[i];
            if (i != t.minterms.size() - 1) cout << ",";
        }
        cout << ")\n";
    }

    cout << "\nMinimal Expression: \n";
    for (int i = 0; i < primeImplicants.size(); i++) {
        printTerm(primeImplicants[i].bits, varNames);
        if (i != primeImplicants.size() - 1) cout << " + ";
    }
    cout << endl;

    return 0;
}

//Example: 
// Enter number of variables: 4
// Enter number of minterms: 6
// Enter minterms (space separated): 4 8 10 11 12 15


